package com.miangs.temloemod.init;

import com.miangs.temloemod.block.BlockFolg;
import com.miangs.temloemod.block.BlockWKgagg;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;

public class  MODBlocks
{
	//public static final Block Blockfkosgggg = new Blockfkosb();
	
	public static final Block block_folg = new BlockFolg();

	public static final Block block_wkgagg = new BlockWKgagg();
	
	
	//public static final RegistryNamespaced<ResourceLocation, Item> REGISTRY = net.minecraftforge.registries.GameData.getWrapper(Item.class);
	
	
	/*
	private static void registerItem(int id, String textualID, Item itemIn)
    {
        registerItem(id, new ResourceLocation(textualID), itemIn);
    }
	
	private static void registerItem(int id, ResourceLocation textualID, Item itemIn)
    {
        REGISTRY.register(id, textualID, itemIn);
    }
    
    
	
	
	public static void Blocksg()
	{
		
		 registerItem(355, "ngggg", new ItemBed());//.setMaxStackSize(1).setUnlocalizedName("bed"));
		
	}
	*/
	
	
	
	
	
	
	
	
	//public static Item Nemgg = new ItemNemgg();
	
	
	//public static final Item Nemgg = new ItemNemgg();
	
	//public static Item Nemgg = new ItemNemgg(), Nemggn = new ItemNemgg();
}
