package com.miangs.temloemod;

import net.minecraft.item.Item;
import net.minecraftforge.fml.common.Mod;

//@Mod.EventBusSubscriber
public class MODiogs
{
	//public static final String nexg = "unfiredclaybucket";
    
   // @GameRegistry.ObjectHolder(TemloeMod.MODID + ":" + nexg)
   // public static Item unfiredClaybucket;
}
