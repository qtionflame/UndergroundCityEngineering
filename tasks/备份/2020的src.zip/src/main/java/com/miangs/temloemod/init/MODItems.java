package com.miangs.temloemod.init;

import com.miangs.temloemod.item.ItemNexg;
import net.minecraft.item.Item;

public class MODItems {
	
	
	public static final Item nexg = new ItemNexg();

}
