package com.miangs.temloemod.item;

import net.minecraft.item.Item;
import net.minecraftforge.fml.common.discovery.ModCandidate;

public class ItemNexg extends Item
{
	public ItemNexg()
	{
		//this.setCreativeTab();
		setUnlocalizedName("NggnexgCzzz");
		setRegistryName("nggnexg_czzz");	//这是我的第一个物品，名字是: moags:aol_cszz-item
	}
}
